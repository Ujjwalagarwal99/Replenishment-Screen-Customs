{
    "name": "Pending PO Details",
    "version": "19.0.1.0.0",
    "author": 'Ujjwal Agarwal',
    "category": "Inventory",
    "summary": "Shows Pending Purchase Order Details in Replenishment",
    "license": "LGPL-3",
    "depends": [
        "stock",
        "purchase_stock",
    ],
    "data": [
        "views/replenishment_views.xml",
    ],
    "installable": True,
    "application": False,
}