from odoo import api, fields, models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    pending_po_details = fields.Html(
        string="Pending PO Details",
        compute="_compute_pending_po_details",
        sanitize=False,
    )

    @api.depends("product_id")
    def _compute_pending_po_details(self):
        PurchaseOrderLine = self.env["purchase.order.line"]

        for record in self:

            html = ""

            if not record.product_id:
                record.pending_po_details = ""
                continue

            po_lines = PurchaseOrderLine.search([
                ("product_id", "=", record.product_id.id),
                ("order_id.state", "in", ["purchase"]),
            ])

            for line in po_lines:

                pending_qty = line.product_qty - line.qty_received

                if pending_qty <= 0:
                    continue

                vendor = line.order_id.partner_id.name or ""
                po = line.order_id.name or ""

                po_date = ""
                if line.order_id.date_order:
                    po_date = line.order_id.date_order.strftime("%d-%b-%Y")

                html += """
                <div style="
                    margin-bottom:2px;
                    padding:2px 6px;
                    border-radius:4px;
                    background:#E8F4FD;
                    color:#004B87;
                    display:inline-block;
                    font-size:12px;">
                    %s | %s | %s | %.2f
                </div><br/>
                """ % (
                    vendor,
                    po,
                    po_date,
                    pending_qty,
                )

            record.pending_po_details = html