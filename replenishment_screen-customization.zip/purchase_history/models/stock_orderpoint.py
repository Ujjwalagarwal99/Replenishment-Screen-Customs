from datetime import date

from odoo import api, fields, models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    x_last_po_vendor = fields.Many2one(
        "res.partner",
        string="Last PO Vendor",
        compute="_compute_purchase_history",
        store=False,
    )

    x_last_po_number = fields.Char(
        string="Last PO",
        compute="_compute_purchase_history",
        store=False,
    )

    x_last_po_date = fields.Date(
        string="Last PO Date",
        compute="_compute_purchase_history",
        store=False,
    )

    x_last_po_qty = fields.Float(
        string="Last PO Qty",
        compute="_compute_purchase_history",
        store=False,
    )

    x_last_po_price = fields.Float(
        string="Last PO Price",
        compute="_compute_purchase_history",
        store=False,
    )

    x_last_receipt_date = fields.Date(
        string="Last Receipt",
        compute="_compute_purchase_history",
        store=False,
    )

    x_last_receipt_qty = fields.Float(
        string="Last Receipt Qty",
        compute="_compute_purchase_history",
        store=False,
    )

    x_purchase_age = fields.Integer(
        string="Purchase Age (Days)",
        compute="_compute_purchase_history",
        store=False,
    )

    @api.depends("product_id")
    def _compute_purchase_history(self):

        PurchaseOrder = self.env["purchase.order"]

        for record in self:

            record.x_last_po_vendor = False
            record.x_last_po_number = False
            record.x_last_po_date = False
            record.x_last_po_qty = 0
            record.x_last_po_price = 0
            record.x_last_receipt_date = False
            record.x_last_receipt_qty = 0
            record.x_purchase_age = 0

            if not record.product_id:
                continue

            po = PurchaseOrder.search(
                [
                    ("state", "in", ["purchase", "done"]),
                    ("order_line.product_id", "=", record.product_id.id),
                ],
                order="date_order desc,id desc",
                limit=1,
            )

            if not po:
                continue

            line = po.order_line.filtered(
                lambda l: l.product_id.id == record.product_id.id
            )

            if not line:
                continue

            line = line[0]

            record.x_last_po_vendor = po.partner_id
            record.x_last_po_number = po.name
            record.x_last_po_date = po.date_order.date() if po.date_order else False
            record.x_last_po_qty = line.product_qty
            record.x_last_po_price = line.price_unit

            pickings = po.picking_ids.filtered(
                lambda p: p.state == "done"
            ).sorted(
                key=lambda p: p.date_done or fields.Datetime.now(),
                reverse=True,
            )

            if pickings:

                picking = pickings[0]

                record.x_last_receipt_date = (
                    picking.date_done.date()
                    if picking.date_done
                    else False
                )

                move = picking.move_ids.filtered(
                    lambda m: m.product_id.id == record.product_id.id
                )

                if move:
                    record.x_last_receipt_qty = sum(move.mapped("quantity"))

            if record.x_last_po_date:
                record.x_purchase_age = (
                    date.today() - record.x_last_po_date
                ).days