{
    "name": "Purchase History",
    "version": "19.0.1.0.0",
    "category": "Inventory",
    "summary": "Display Last Purchase History on Replenishment",
    "description": """
ATEK Purchase History

Features
--------
- Last PO Vendor
- Last PO Number
- Last PO Date
- Last PO Qty
- Last PO Rate
- Last Receipt Date
- Last Receipt Qty
- Purchase Age
    """,
    "author": 'Ujjwal Agarwal',
    "website": "",
    "license": "LGPL-3",
    "depends": [
        "stock",
        "purchase",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/stock_orderpoint_views.xml",
    ],
    "installable": True,
    "application": False,
}