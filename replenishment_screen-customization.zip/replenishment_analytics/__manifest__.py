{
    "name": "Replenishment Analytics",
    "version": "19.0.1.0.0",
    "summary": "Replenishment Purchase History & Analytics",
    "author": 'Ujjwal Agarwal',
    "category": "Inventory",

    "depends": [
        "stock",
        "purchase_stock",
        "web",
    ],

    "data": [
        "views/replenishment_tree.xml",
    ],

    "assets": {
        "web.assets_backend": [
            "atek_replenishment_analytics/static/src/js/search_panel.js",
        ],
    },

    "installable": True,
    "application": False,
    "license": "LGPL-3",
}