/** @odoo-module **/

console.log("ATEK Replenishment Analytics Loaded");