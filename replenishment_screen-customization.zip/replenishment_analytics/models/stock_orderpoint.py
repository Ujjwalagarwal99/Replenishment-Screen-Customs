from odoo import api, fields, models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    purchase_qty = fields.Float(
        string="Purchase Qty",
        compute="_compute_purchase_qty",
        digits="Product Unit of Measure",
    )

    @api.depends("product_id")
    def _compute_purchase_qty(self):
        PurchaseLine = self.env["purchase.order.line"]

        ICP = self.env["ir.config_parameter"].sudo()

        date_from = ICP.get_param("atek.purchase_date_from")
        date_to = ICP.get_param("atek.purchase_date_to")

        for orderpoint in self:
            orderpoint.purchase_qty = 0.0

            if not orderpoint.product_id:
                continue

            domain = [
                ("product_id", "=", orderpoint.product_id.id),
                ("order_id.state", "=", "purchase"),
            ]

            if date_from:
                domain.append(("order_id.date_order", ">=", date_from))

            if date_to:
                domain.append(("order_id.date_order", "<=", date_to))

            lines = PurchaseLine.search(domain)

            orderpoint.purchase_qty = sum(lines.mapped("product_qty"))