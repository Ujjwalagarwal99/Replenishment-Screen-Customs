{
    "name": "Pending Vendor Purchase Orders",
    'author': 'Ujjwal Agarwal',
    "version": "19.0.1.0.0",
    "category": "Inventory/Purchase",
    "summary": "View pending confirmed purchase orders by vendor from Replenishment",
    "depends": [
        "stock",
        "purchase",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/stock_orderpoint_views.xml",
        "wizard/pending_vendor_po_wizard_views.xml",
    ],
    "installable": True,
    "application": False,
    "license": "LGPL-3",
}