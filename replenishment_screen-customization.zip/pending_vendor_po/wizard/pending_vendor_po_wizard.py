from collections import defaultdict

from odoo import api, fields, models


class PendingVendorPoWizard(models.TransientModel):
    _name = "pending.vendor.po.wizard"
    _description = "Pending Vendor Purchase Orders"

    orderpoint_id = fields.Many2one(
        "stock.warehouse.orderpoint",
        string="Replenishment",
        readonly=True,
    )

    product_id = fields.Many2one(
        "product.product",
        string="Starting Product",
        readonly=True,
    )

    location_id = fields.Many2one(
        "stock.location",
        string="Location",
        readonly=True,
    )

    allowed_vendor_ids = fields.Many2many(
        "res.partner",
        string="Allowed Vendors",
        compute="_compute_allowed_vendor_ids",
    )

    vendor_id = fields.Many2one(
        "res.partner",
        string="Vendor",
        required=True,
        domain="[('id', 'in', allowed_vendor_ids)]",
    )

    line_ids = fields.One2many(
        "pending.vendor.po.wizard.line",
        "wizard_id",
        string="Pending Items",
    )

    total_pending_qty = fields.Float(
        string="Total Pending Quantity",
        compute="_compute_total_pending_qty",
    )

    @api.depends("product_id")
    def _compute_allowed_vendor_ids(self):
        SupplierInfo = self.env["product.supplierinfo"]

        for wizard in self:
            wizard.allowed_vendor_ids = self.env["res.partner"]

            if not wizard.product_id:
                continue

            supplier_infos = SupplierInfo.search([
                (
                    "product_tmpl_id",
                    "=",
                    wizard.product_id.product_tmpl_id.id,
                ),
            ])

            wizard.allowed_vendor_ids = supplier_infos.mapped("partner_id")

    @api.depends("line_ids.pending_qty")
    def _compute_total_pending_qty(self):
        for wizard in self:
            wizard.total_pending_qty = sum(
                wizard.line_ids.mapped("pending_qty")
            )

    @api.onchange("vendor_id")
    def _onchange_vendor_id(self):
        if not self.vendor_id:
            self.line_ids = [fields.Command.clear()]
            return

        self.line_ids = [
            fields.Command.clear(),
            *self._prepare_pending_lines(self.vendor_id),
        ]

    def _prepare_pending_lines(self, vendor):
        PurchaseOrderLine = self.env["purchase.order.line"]

        po_lines = PurchaseOrderLine.search([
            ("partner_id", "=", vendor.id),
            ("order_id.state", "=", "purchase"),
            ("product_id", "!=", False),
        ])

        grouped = defaultdict(lambda: {
            "ordered_qty": 0.0,
            "received_qty": 0.0,
            "pending_qty": 0.0,
            "purchase_line_ids": [],
        })

        for line in po_lines:
            pending_qty = line.product_qty - line.qty_received

            if pending_qty <= 0:
                continue

            product = line.product_id

            key = product.id

            grouped[key]["ordered_qty"] += line.product_qty
            grouped[key]["received_qty"] += line.qty_received
            grouped[key]["pending_qty"] += pending_qty
            grouped[key]["purchase_line_ids"].append(line.id)

        commands = []

        for product_id, values in grouped.items():
            commands.append(
                fields.Command.create({
                    "product_id": product_id,
                    "ordered_qty": values["ordered_qty"],
                    "received_qty": values["received_qty"],
                    "pending_qty": values["pending_qty"],
                    "purchase_line_ids": [
                        fields.Command.set(values["purchase_line_ids"])
                    ],
                })
            )

        return commands

    def action_view_pending_orders(self):
        self.ensure_one()

        if self.vendor_id:
            self.line_ids = [
                fields.Command.clear(),
                *self._prepare_pending_lines(self.vendor_id),
            ]

        return {
            "type": "ir.actions.act_window",
            "name": "Pending Vendor Purchase Orders",
            "res_model": "pending.vendor.po.wizard",
            "view_mode": "form",
            "res_id": self.id,
            "target": "new",
        }


class PendingVendorPoWizardLine(models.TransientModel):
    _name = "pending.vendor.po.wizard.line"
    _description = "Pending Vendor Purchase Order Summary"

    wizard_id = fields.Many2one(
        "pending.vendor.po.wizard",
        required=True,
        ondelete="cascade",
    )

    product_id = fields.Many2one(
        "product.product",
        string="Product",
        readonly=True,
    )

    ordered_qty = fields.Float(
        string="Ordered Qty",
        readonly=True,
    )

    received_qty = fields.Float(
        string="Received Qty",
        readonly=True,
    )

    pending_qty = fields.Float(
        string="Pending Qty",
        readonly=True,
    )

    purchase_line_ids = fields.Many2many(
        "purchase.order.line",
        string="Purchase Lines",
        readonly=True,
    )

    def action_view_purchase_lines(self):
        self.ensure_one()

        return {
            "type": "ir.actions.act_window",
            "name": "Purchase Order Lines",
            "res_model": "purchase.order.line",
            "view_mode": "list,form",
            "domain": [
                ("id", "in", self.purchase_line_ids.ids),
            ],
            "target": "current",
        }