from odoo import models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    def action_pending_vendor_po(self):
        self.ensure_one()

        return {
            "type": "ir.actions.act_window",
            "name": "Pending Vendor Purchase Orders",
            "res_model": "pending.vendor.po.wizard",
            "view_mode": "form",
            "target": "new",
            "context": {
                "default_product_id": self.product_id.id,
                "default_location_id": self.location_id.id,
                "default_orderpoint_id": self.id,
            },
        }