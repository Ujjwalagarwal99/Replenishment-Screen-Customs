{
    "name": "Pending PO Quantity",
    "version": "19.0.1.0.1",
    "summary": "Show Pending Purchase Order Quantity in Replenishment",
    "author": 'Ujjwal Agarwal',
    "category": "Inventory",
    "license": "LGPL-3",
    "depends": [
        "stock",
        "purchase",
    ],
    "data": [
        "views/replenishment_views.xml",
    ],
    "installable": True,
    "application": False,
}