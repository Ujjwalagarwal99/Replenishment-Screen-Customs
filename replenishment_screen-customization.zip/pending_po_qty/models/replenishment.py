from odoo import api, fields, models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    pending_po_qty = fields.Float(
        string="Pending PO Qty",
        compute="_compute_pending_po_qty",
        digits="Product Unit of Measure",
    )

    @api.depends("product_id")
    def _compute_pending_po_qty(self):
        PurchaseOrderLine = self.env["purchase.order.line"]

        for record in self:
            qty = 0.0

            lines = PurchaseOrderLine.search([
                ("product_id", "=", record.product_id.id),
                ("order_id.state", "in", ["purchase", "done"]),
            ])

            for line in lines:
                pending = line.product_qty - line.qty_received
                if pending > 0:
                    qty += pending

            record.pending_po_qty = qty