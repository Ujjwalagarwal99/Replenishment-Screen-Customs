from odoo import models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    def action_open_purchase_history(self):
        return self.env.ref(
            "atek_replenishment_date_filter.action_purchase_history_wizard"
        ).read()[0]