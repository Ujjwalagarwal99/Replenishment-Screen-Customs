from datetime import date

from dateutil.relativedelta import relativedelta

from odoo import api, fields, models


class PurchaseHistoryWizard(models.TransientModel):
    _name = "purchase.history.wizard"
    _description = "Purchase History Date Filter"

    period = fields.Selection(
        [
            ("1m", "Last 1 Month"),
            ("3m", "Last 3 Months"),
            ("6m", "Last 6 Months"),
            ("12m", "Last 12 Months"),
            ("cm", "Current Month"),
            ("pm", "Previous Month"),
            ("cfy", "Current Financial Year"),
            ("pfy", "Previous Financial Year"),
            ("all", "All Purchase History"),
            ("custom", "Custom Date"),
        ],
        string="Purchase Period",
        default="1m",
        required=True,
    )

    date_from = fields.Date(string="From Date")
    date_to = fields.Date(string="To Date")

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)

        today = fields.Date.today()

        res.update({
            "period": "1m",
            "date_from": today - relativedelta(months=1),
            "date_to": today,
        })

        return res

    def _set_date_range(self, date_from, date_to):
        self.date_from = date_from
        self.date_to = date_to

    @api.onchange("period")
    def _onchange_period(self):
        today = fields.Date.today()

        if self.period == "1m":
            self._set_date_range(
                today - relativedelta(months=1),
                today,
            )

        elif self.period == "3m":
            self._set_date_range(
                today - relativedelta(months=3),
                today,
            )

        elif self.period == "6m":
            self._set_date_range(
                today - relativedelta(months=6),
                today,
            )

        elif self.period == "12m":
            self._set_date_range(
                today - relativedelta(months=12),
                today,
            )

        elif self.period == "cm":
            self._set_date_range(
                today.replace(day=1),
                today,
            )

        elif self.period == "pm":
            first_day_current = today.replace(day=1)
            last_day_previous = first_day_current - relativedelta(days=1)

            self._set_date_range(
                last_day_previous.replace(day=1),
                last_day_previous,
            )

        elif self.period == "cfy":
            if today.month >= 4:
                self._set_date_range(
                    date(today.year, 4, 1),
                    today,
                )
            else:
                self._set_date_range(
                    date(today.year - 1, 4, 1),
                    today,
                )

        elif self.period == "pfy":
            if today.month >= 4:
                self._set_date_range(
                    date(today.year - 1, 4, 1),
                    date(today.year, 3, 31),
                )
            else:
                self._set_date_range(
                    date(today.year - 2, 4, 1),
                    date(today.year - 1, 3, 31),
                )

        elif self.period == "all":
            self._set_date_range(False, False)

        elif self.period == "custom":
            self._set_date_range(False, False)

    def action_apply(self):
        ICP = self.env["ir.config_parameter"].sudo()

        ICP.set_param(
            "atek.purchase_date_from",
            self.date_from.isoformat() if self.date_from else "",
        )

        ICP.set_param(
            "atek.purchase_date_to",
            self.date_to.isoformat() if self.date_to else "",
        )

        return {
            "type": "ir.actions.client",
            "tag": "reload",
        }