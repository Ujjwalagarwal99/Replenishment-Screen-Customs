{
    "name": "Replenishment Date Filter",
    "version": "19.0.1.0.0",
    "author": 'Ujjwal Agarwal',
    "category": "Inventory",
    "summary": "Adds a custom date filter for replenishment purchase history.",

    "depends": [
        "stock",
        "purchase_stock",
        "atek_replenishment_analytics",
    ],

    "data": [
        "security/ir.model.access.csv",
        "views/purchase_history_wizard.xml",
    ],

    "installable": True,
    "application": False,
    "license": "LGPL-3",
}