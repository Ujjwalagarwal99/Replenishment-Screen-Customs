{
    "name": "Order To Max - Exact Max Quantity",
    "version": "19.0.1.0.0",
    "category": "Inventory/Inventory",
    "summary": "Create RFQ with exactly the Max Quantity from Replenishment",
    "description": """
ATEK Order To Max customization.

When Order To Max is selected from Replenishment,
the RFQ quantity will be exactly equal to Max Quantity.

Example:
Max Quantity = 1800
Required Quantity = 27

Standard Odoo:
1800 + 27 = 1827

ATEK customization:
RFQ Quantity = 1800

Normal Order behavior remains unchanged.
""",
    "author": 'Ujjwal Agarwal',
    "license": "LGPL-3",
    "depends": [
        "stock",
        "purchase_stock",
    ],
    "data": [],
    "installable": True,
    "application": False,
}