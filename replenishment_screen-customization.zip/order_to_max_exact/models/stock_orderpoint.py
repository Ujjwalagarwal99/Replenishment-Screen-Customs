from odoo import models


class StockWarehouseOrderpoint(models.Model):
    _inherit = "stock.warehouse.orderpoint"

    def action_replenish(self, force_to_max=False):
        if force_to_max:
            for orderpoint in self:
                orderpoint.qty_to_order = orderpoint._get_multiple_rounded_qty(
                    orderpoint.product_max_qty
                )
            force_to_max = False

        return super().action_replenish(force_to_max=force_to_max)